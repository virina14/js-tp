const express = require('express');
const app = express();
const path = require('path');
const port = 8060;

// Настройка для обслуживания статических файлов (HTML, CSS, изображения и т.д.)
app.use(express.static(path.join(__dirname, 'public')));

// Главная страница - это ваш HTML файл
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

// Запуск сервера
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
